# Title: Matching Game
This README includes: steps and **problems** need to be solved.
## Steps
- quweryselect deck html 
- toggle cards
- check for match
- shuffle the deck
- add moves/ hide stars/ set clock
- modal stats
- restart the game
## Problem
- Modal - stats - moves :
  `Moves : ${moves+1}` -- because doen't show the correct moves

